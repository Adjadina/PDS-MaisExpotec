package meavalie.pi.ifrn.edu.br.meavalie.services;

import java.util.List;

import meavalie.pi.ifrn.edu.br.meavalie.dominio.Avaliacao;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by aluno on 03/07/18.
 */

public interface AvaliacaoService {

    @GET("avaliacoes/{idAvaliador}")
    Call<List<Avaliacao>> buscarAvaliacoes(@Path("idAvaliador")int idAvaliador);

    @POST("avaliacoes")
    Call<Boolean> adicionar(@Body Avaliacao avaliacao);
}
