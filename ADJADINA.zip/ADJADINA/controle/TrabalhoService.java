package meavalie.pi.ifrn.edu.br.meavalie.services;

import java.util.List;

import meavalie.pi.ifrn.edu.br.meavalie.dominio.Trabalho;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/**
 * Created by aluno on 21/06/18.
 */

public interface TrabalhoService {

    @GET("trabalhos/{idTrabalho}")
    Call<Trabalho> buscarTrabalho(@Path("idTrabalho") int idTrabalho);

    @DELETE("trabalhos/{idTrabalho}")
    Call<Boolean> remover(@Path("idTrabalho") int idTrabalho);

    @GET("trabalhos")
    Call<List<Trabalho>> buscarTrabalhos();

    @POST("trabalhos")
    Call<Boolean> adicionar(@Body Trabalho trabalho);

    @PUT("trabalhos")
    Call<Boolean> atualizar(@Body Trabalho trabalho);
}
