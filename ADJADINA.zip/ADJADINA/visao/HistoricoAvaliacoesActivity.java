package meavalie.pi.ifrn.edu.br.meavalie.telas;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.List;

import meavalie.pi.ifrn.edu.br.meavalie.R;
import meavalie.pi.ifrn.edu.br.meavalie.dominio.Pessoa;
import meavalie.pi.ifrn.edu.br.meavalie.services.RetrofitConfig;
import meavalie.pi.ifrn.edu.br.meavalie.dominio.Avaliacao;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HistoricoAvaliacoesActivity extends AppCompatActivity implements MyRecyclerViewAdapter.MyClickListener {
    private RecyclerView mRecyclerView;
    private MyRecyclerViewAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private static String LOG_TAG = "HistoricoAvaliacoesActivity";
    private Pessoa pessoa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_historico_avaliacoes);
        mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(HistoricoAvaliacoesActivity.this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator intengrator = new IntentIntegrator(HistoricoAvaliacoesActivity.this);
                intengrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                intengrator.setPrompt("Leitor QR");
                intengrator.setCameraId(0);
                intengrator.initiateScan();
            }
        });

        pessoa = new Pessoa();
        pessoa.setIdPessoa(1);

        getDataSet();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() != null) {
                int idTrabalho = Integer.parseInt(result.getContents());
                Log.e("TESTE", String.valueOf(idTrabalho));
                //mAdapter.addItem(item);
                Intent intent = new Intent(this, InformacoesActivity.class);
                intent.putExtra("trabalho", idTrabalho);
                intent.putExtra("pessoa", pessoa);
                startActivity(intent);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void getDataSet() {

        Call<List<Avaliacao>> call = new RetrofitConfig().getAvaliacaoService().buscarAvaliacoes(pessoa.getIdPessoa());
        call.enqueue(new Callback<List<Avaliacao>>() {
            @Override
            public void onResponse(Call<List<Avaliacao>> call, Response<List<Avaliacao>> response) {

                List<Avaliacao> avaliacoes =  response.body();

                mAdapter = new MyRecyclerViewAdapter(avaliacoes, HistoricoAvaliacoesActivity.this);
                mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<List<Avaliacao>> call, Throwable t) {
                Log.e("AvaliacaoService   ", "Erro ao recuperar trabalhos avaliados:" + t.getMessage());
            }
        });

    }

    @Override
    public void onItemClick(Avaliacao avaliacao) {
        Intent intent = new Intent(getApplicationContext(), InformacoesActivity.class);
        intent.putExtra("avaliacao", mAdapter.getItem());
        intent.putExtra("pessoa", pessoa);
        startActivity(intent);
    }
}
