package meavalie.pi.ifrn.edu.br.meavalie.dominio;

import java.io.Serializable;
import java.util.ArrayList;

import meavalie.pi.ifrn.edu.br.meavalie.dominio.Modalidade;
import meavalie.pi.ifrn.edu.br.meavalie.dominio.Pessoa;

public class Trabalho implements Serializable {

    private int idTrabalho; //chave primaria da classe trabalho
    private Modalidade modalidade; //chave estrangeira da classe modalidade
    private String titulo;
    private String resumo;
    private ArrayList<Pessoa> autores;

    public Trabalho() {

    }

    public Trabalho(int idTrabalho, Modalidade modalidade, String titulo, String resumo, ArrayList<Pessoa> autores) {
        this.idTrabalho = idTrabalho;
        this.modalidade = modalidade;
        this.titulo = titulo;
        this.resumo = resumo;
        this.autores = autores;
    }

    public int getIdTrabalho() { return idTrabalho; }

    public void setIdTrabalho(int idTrabalho) { this.idTrabalho = idTrabalho; }

    public Modalidade getModalidade() { return modalidade; }

    public void setModalidade(Modalidade modalidade) { this.modalidade = modalidade; }

    public String getTitulo() { return titulo; }

    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getResumo() { return resumo; }

    public void setResumo(String resumo) { this.resumo = resumo; }

    public ArrayList<Pessoa> getAutores() { return autores; }

    public void setAutores(ArrayList<Pessoa> autores) { this.autores = autores; }

}
