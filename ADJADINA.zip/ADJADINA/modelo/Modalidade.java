package meavalie.pi.ifrn.edu.br.meavalie.dominio;

import java.io.Serializable;

/**
 * Created by aluno on 25/06/18.
 */

public class Modalidade implements Serializable {
    private int idModalidade;
    private String descricao;

    public int getIdModalidade() {
        return idModalidade;
    }

    public void setIdModalidade(int idModalidade) {
        this.idModalidade = idModalidade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
