package meavalie.pi.ifrn.edu.br.meavalie.dominio;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by aluno on 03/07/18.
 */
public class Avaliacao implements Serializable{
    private int idPessoa; //chave estrangeira da classe pessoa
    private Trabalho trabalho; //chave estrangeira da classe trabalho
    private Date divulgacao;
    private Date avaliacao;
    private double nota;

    public int getIdPessoa() { return idPessoa; }

    public void setIdPessoa(int idPessoa) { this.idPessoa = idPessoa; }

    public Trabalho getTrabalho() { return trabalho; }

    public void setTrabalho(Trabalho trabalho) { this.trabalho = trabalho; }

    public Date getDivulgacao() { return divulgacao; }

    public void setDivulgacao(Date divulgacao) { this.divulgacao = divulgacao; }

    public Date getAvaliacao() { return avaliacao; }

    public void setAvaliacao(Date avaliacao) { this.avaliacao = avaliacao; }

    public double getNota() { return nota; }

    public void setNota(double nota) { this.nota = nota; }
}
